import os
import shutil
import csv

current_path = os.getcwd()
folder_list = os.listdir(current_path)

# num = 0
# for folder in folder_list:materials
   
#     model_name = folder
#     print(f'<model name="{model_name}">\n' \
#         '\t<include>\n' \
#         f'\t\t<uri>model://qrcode/{model_name}</uri>\n' \
#         '\t</include>\n' \
#         '\t<pose frame="">0 0 0.01 0 0 0</pose>\n' \
#         '</model>')
for folder_name in folder_list:
    current_path = f'{current_path}/materials'
    os.mkdir(current_path)